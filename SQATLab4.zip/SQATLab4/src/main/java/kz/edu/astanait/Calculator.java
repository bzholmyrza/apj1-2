package kz.edu.astanait;

public class Calculator {

    public int getSum(int x, int y) {
        return x + y;
    }

    public int getSubtraction(int x, int y) {
        return x - y;
    }

    public int getDivide(int x, int y) {
        return x / y;
    }

    public int getMultiple(int x, int y) {
        return x * y;
    }

}
